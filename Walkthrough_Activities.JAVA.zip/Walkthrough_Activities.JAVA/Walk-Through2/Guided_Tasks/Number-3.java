public class ControlFlow {

    public static void main(String[] args) {
        int num =10;
        while (num>-1) {
        	if(num!=0) {
        		System.out.println(num);
        	}
             num--;
    }
    }
}
