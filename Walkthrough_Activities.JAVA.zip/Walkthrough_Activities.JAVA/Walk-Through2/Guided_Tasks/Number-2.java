import java.util.Scanner;

public class ControlFlow {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.print("Enter a number to display the day (1-7) or 0 to exit: ");
            int choice = scanner.nextInt();
            
            if (choice == 0) {
                System.out.println("Goodbye!");
                break; 
            }
            
            switch (choice) {
                case 1:
                    System.out.println("Monday");
                    break;
                case 2:
                    System.out.println("Tuesday");
                    break;
                case 3:
                    System.out.println("Wednesday");
                    break;
                case 4:
                    System.out.println("Thursday");
                    break;
                case 5:
                    System.out.println("Friday");
                    break;
                case 6:
                    System.out.println("Saturday");
                    break;
                case 7:
                    System.out.println("Sunday");
                    break;
                default:
                    System.out.println("Invalid Input! Please enter a number between 1 and 7.");
            }
        }

        scanner.close(); 
    }
}
